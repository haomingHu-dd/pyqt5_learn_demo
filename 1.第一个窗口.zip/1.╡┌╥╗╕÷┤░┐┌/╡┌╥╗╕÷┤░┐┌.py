"""
/********************************************************************************
* @Filename: 第一个窗口.py
* @Author: haomingHu
* @Version: 1.0
* @Date:  2020-12-16
* @Description: 
* @History: 
********************************************************************************/
"""
from PyQt5 import QtWidgets##从 PyQt 库导入 QtWidget 通用窗口类

import sys

class mywindow(QtWidgets.QWidget):#继承 QtWidgets.QWidget 类方法
    def __init__(self):
        super(mywindow,self).__init__()


def maingui():
    app = QtWidgets.QApplication(sys.argv)##pyqt 窗口必须在 QApplication 方法中使用
    window = mywindow()#实例化对象
    window.show()#显示窗口
    sys.exit(app.exec_())#启动事件循环

if __name__ == "__main__":
    print("haoming Hu welcome!")
    maingui()
