from ui3 import Ui_Form
import sys,time
from PyQt5 import QtWidgets,QtCore


class mydesigner(QtWidgets.QWidget,Ui_Form):
    #定义自定义信号
    signal_1 = QtCore.pyqtSignal()#不带参数

    signal_2 = QtCore.pyqtSignal(int)#带int型参数

    signal_3 = QtCore.pyqtSignal(int,str)#带int和str两个参数

    signal_4 = QtCore.pyqtSignal(list)#带列表型

    signal_5 = QtCore.pyqtSignal(dict)#带字典型

    def __init__(self):
        super(mydesigner,self).__init__()
        self.setupUi(self)

        #为自定义的信号绑定自定义函数，当接收者接收到这个信号的时候，将会执行这个函数
        self.signal_1.connect(self.signal_1_response)
        self.signal_2.connect(self.signal_2_response)
        self.signal_3.connect(self.signal_3_response)
        self.signal_4.connect(self.signal_4_response)
        self.signal_5.connect(self.signal_5_response)
        
        self.pushButton_1.clicked.connect(self.signal_1_call)
        self.pushButton_2.clicked.connect(self.signal_2_call)
        self.pushButton_3.clicked.connect(self.signal_3_call)
        self.pushButton_4.clicked.connect(self.signal_4_call)
        self.pushButton_5.clicked.connect(self.signal_5_call)
        
    def signal_1_call(self):
        self.signal_1.emit()

    def signal_2_call(self):
        self.signal_2.emit(1)

    def signal_3_call(self):
        self.signal_3.emit(1,"test")

    def signal_4_call(self):
        self.signal_4.emit([1,2,3,4])

    def signal_5_call(self):
        self.signal_5.emit({"name":"huhaoming","age":"20"})

    #自定义的槽函数
    def signal_1_response(self):
        print("不带参数")
    def signal_2_response(self,val):
        print("带整形参数：",val)
        
    def signal_3_response(self,val_int,val_str):
        print("带int和str两个参数:",val_int,val_str)
    def signal_4_response(self,val):
        print("带列表型：",val)
    def signal_5_response(self,val):
        print("带字典型：",val)

  
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myshow = mydesigner()
    myshow.show()
    sys.exit(app.exec_())