"""
/********************************************************************************
* @Filename: 信号与槽初试.py
* @Author: haomingHu
* @Version: 1.0
* @Date:  2020-12-16
* @Description: 
* @History: 
********************************************************************************/
"""
from ui2 import Ui_Form#导入在QTdesigner设计好的 ui.py 文件
import sys
from PyQt5 import QtWidgets


class mydesigner(QtWidgets.QWidget,Ui_Form):
    def __init__(self):
        super(mydesigner,self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.signaltest)
    def signaltest(self):
        print("haomingHu")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myshow = mydesigner()
    myshow.show()
    sys.exit(app.exec_())