"""
/********************************************************************************
* @Filename: main.py
* @Author: haomingHu
* @Version: 1.0
* @Date:  2021-03-26
* @Description: 
* @History: 
********************************************************************************/
"""



from login_ui import Ui_login
from main_ui  import Ui_main
import sys
from PyQt5 import QtWidgets
from PyQt5.QtGui import QPalette,QBrush,QPixmap
from PyQt5.QtCore import Qt

class myLogin(QtWidgets.QWidget,Ui_login):
    login_state = 0 
    def __init__(self):
        super(myLogin,self).__init__()
        self.setupUi(self)
        loginPalette = QPalette()
        loginPalette.setBrush(QPalette.Background, QBrush(QPixmap("./6.窗口跳转（注册登录）/loginbackground.jpg")))
        #loginPalette.setColor(QPalette.Background, Qt.blue)
        self.setPalette(loginPalette)

class myMainGui(QtWidgets.QWidget,Ui_main):
    userID = ""
    #构造函数
    def __init__(self):
        super(myMainGui,self).__init__()
        self.setupUi(self)

    def closeEvent(self,event):#函数名固定不可变
        reply=QtWidgets.QMessageBox.question(self,u'Notice!',u'Are you  sure to exit?'
            ,QtWidgets.QMessageBox.Yes,QtWidgets.QMessageBox.No)
        #QtWidgets.QMessageBox.question(self,u'弹窗名',u'弹窗内容',选项1,选项2)
        if reply==QtWidgets.QMessageBox.Yes:
            event.accept()#关闭窗口
        else:
            event.ignore()#忽视点击X事件



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myLogin = myLogin()
    myLogin.show()
    mainGUI = myMainGui()
    
    userIDSure = ""
    flag = 0
    def login_check():
        userID = myLogin.lineEdit_id.text()
        user_PW = myLogin.lineEdit_pw.text()
        print(type(user_PW))
        print(userID)
        print(user_PW)
        
        '''
        这里我使用的是我服务器的登录请求接口
        使用的时候换成自己封装好的登录验证接口即可
        '''
        
        '''
        正常来说，登录成功的话，需要将登陆成功的用户信息回传给主界面
        也就是告诉主界面，是哪个用户登录了，这个时候可以在主界面的类中定义
        一些类属性，如果登录成功，则将lineedit对象的输入内容赋值给类属性即可
        '''
        #login_flag = event.loginRequest(userID,user_PW)
        #if login_flag == 0:
        if userID == "1" and user_PW == "1":
            myLogin.login_state = 1
            mainGUI.userID = myLogin.lineEdit_id.text()
            myLogin.close()
            mainGUI.show()
            
    myLogin.login_pushButton.clicked.connect(login_check)

    sys.exit(app.exec_())