"""
/********************************************************************************
* @Filename: 装饰器信号与槽.py
* @Author: haomingHu
* @Version: 1.0
* @Date:  2020-12-16
* @Description: 
* @History: 
********************************************************************************/
"""
from ui4 import Ui_Form#导入在QTdesigner设计好的 ui.py 文件
import sys
from PyQt5 import QtWidgets,QtCore

class mydesigner(QtWidgets.QWidget,Ui_Form):
    def __init__(self):
        super(mydesigner,self).__init__()
        self.setupUi(self)
        

        QtCore.QMetaObject.connectSlotsByName(self)

    @QtCore.pyqtSlot()
    def on_open_clicked(self):
        self.calendarWidget.close()

    @QtCore.pyqtSlot()
    def on_close_clicked(self):
        self.calendarWidget.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myshow = mydesigner()
    myshow.show()
    sys.exit(app.exec_())