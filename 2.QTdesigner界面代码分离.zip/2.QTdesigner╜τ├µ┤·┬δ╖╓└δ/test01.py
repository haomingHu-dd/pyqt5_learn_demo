from ui import Ui_Form#导入在QTdesigner设计好的 ui.py 文件
import sys
from PyQt5 import QtWidgets


class mydesigner(QtWidgets.QWidget):
    def __init__(self):
        super(mydesigner,self).__init__()
        self.new = Ui_Form()#创建实例  
        #也可以直接让mydesigner这个类继承自定义的Ui_Form类，此时可以直接self.setupUi,
        self.new.setupUi(self)#加载窗体，但是还未显示出来


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myshow = mydesigner()
    myshow.show()
    sys.exit(app.exec_())